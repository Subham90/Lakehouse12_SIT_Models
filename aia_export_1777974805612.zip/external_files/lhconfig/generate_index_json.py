#!/usr/bin/env python3
"""
Generate index JSON files for entities used in a transformation (context).
Output is written to a subfolder named after the target entity (e.g. Customer/, ArCharge/).
Columns in each index = columns used in the transformation SQL for that table
+ relation keys (PK/FK from context) + system columns. Datatypes come from
model/data/INTEGRATIONLAYER/ExternalEntity (attributes[].attributeKey, datatype).

Usage:
  python generate_index_json.py <data_path> <transformation_key>
  python generate_index_json.py <data_path> <transformation_key> --entity TABLE_CUSTOMER

Example (all tables -> lhconfig/Customer/):
  python generate_index_json.py ../../data/INTEGRATIONLAYER aLDMCustomerDataChannel-Customer-Customer

Example (one table only):
  python generate_index_json.py ../../data/INTEGRATIONLAYER aLDMCustomerDataChannel-Customer-Customer --entity TABLE_CUSTOMER
"""
import json
import re
import sys
from pathlib import Path

# System columns appended to every index
SYSTEM_COLUMNS = [
    {"columnName": "transaction_update_time__", "dataType": "TIMESTAMP", "expression": None},
    {"columnName": "transaction_resolver__", "dataType": "STRING", "expression": None},
    {"columnName": "op_type__", "dataType": "STRING", "expression": None},
    {"columnName": "source_loading_batch_ts__", "dataType": "TIMESTAMP", "expression": None},
]


def normalize_datatype(dt):
    """Normalize datatype for index JSON (e.g. VARCHAR(4000) -> VARCHAR)."""
    if not dt:
        return "STRING"
    if "(" in dt:
        return dt.split("(")[0].strip()
    return dt.upper()


def load_transformation(data_root: Path, transformation_key: str) -> dict:
    """Load transformation JSON by key. Raises if not found."""
    trans_dir = data_root / "Transformation"
    for f in trans_dir.iterdir():
        if not f.is_file():
            continue
        try:
            with open(f) as fp:
                t = json.load(fp)
            if t.get("key") == transformation_key:
                return t
        except (json.JSONDecodeError, IOError):
            continue
    raise ValueError(f"Transformation key not found: {transformation_key}")


def get_context_key_from_transformation(data_root: Path, transformation_key: str) -> str:
    """Find contextKey for the given transformation key."""
    t = load_transformation(data_root, transformation_key)
    return t.get("contextKey")


def load_context(data_root: Path, context_key: str) -> dict:
    """Load context JSON by contextKey."""
    ctx_dir = data_root / "Context"
    for f in ctx_dir.iterdir():
        if not f.is_file():
            continue
        try:
            with open(f) as fp:
                c = json.load(fp)
            if c.get("contextKey") == context_key:
                return c
        except (json.JSONDecodeError, IOError):
            continue
    raise ValueError(f"Context not found: {context_key}")


def get_entities_from_context(context: dict) -> list:
    """Return list of (schemaStoreKey, entityStoreKey) from context, skipping null entity."""
    out = []
    for ce in context.get("contextEntities", []):
        schema = ce.get("schemaStoreKey")
        entity = ce.get("entityStoreKey")
        if schema and entity:
            out.append((schema, entity))
    return out


def get_alias_to_entity_and_entity_list(context: dict) -> tuple[dict, list]:
    """
    Returns (alias_to_schema_entity, entities).
    alias_to_schema_entity: map SQL alias (upper) -> (schema, entity)
    entities: list of (schema, entity) for iteration.
    """
    alias_map = {}
    entities = []
    for ce in context.get("contextEntities", []):
        schema = ce.get("schemaStoreKey")
        entity = ce.get("entityStoreKey")
        alias = (ce.get("sourceAlias") or "").strip()
        if schema and entity and alias:
            alias_map[alias.upper()] = (schema, entity)
            entities.append((schema, entity))
    return alias_map, entities


def get_relation_columns_per_entity(
    context: dict,
    data_root: Path,
) -> dict:
    """
    For each (schema, entity) in the context, return the set of column names required
    by context relations: primary key columns (for JOINs when this entity is parent or in OTO)
    and foreign key columns (when this entity is child in MTO/OTM/MTM).
    Returns: (schema, entity) -> set of column names.
    """
    result = {}
    for ce in context.get("contextEntities", []):
        schema = ce.get("schemaStoreKey")
        entity = ce.get("entityStoreKey")
        source_alias = (ce.get("sourceAlias") or "").strip().upper()
        foreign_keys_str = ce.get("foreignKeys")
        if not schema or not entity:
            continue

        cols = set()

        # Load entity to get primary key columns
        if schema == "CACHE":
            ent = load_cache_entity(data_root, entity)
        else:
            ent = load_external_entity(data_root, schema, entity)
        if ent:
            attrs = ent.get("attributes", [])
            for a in attrs:
                key_pos = a.get("keyPosition")
                if key_pos is not None:
                    col = a.get("name") or a.get("attributeKey")
                    if col:
                        cols.add(col)

        # Parse foreignKeys: columns of *this* entity that participate in the relation
        # Format can be "COL" or "ALIAS.COL" or "ALIAS.COL,PARENT.COL" (child cols, parent cols)
        if foreign_keys_str:
            for part in foreign_keys_str.split(","):
                part = part.strip()
                if not part:
                    continue
                if "." in part:
                    alias_col = part.split(".", 1)
                    alias, col = alias_col[0].strip().upper(), alias_col[1].strip()
                    if alias == source_alias and col:
                        cols.add(col)
                else:
                    # No alias: single column belonging to this (child) entity
                    cols.add(part)

        result[(schema, entity)] = cols
    return result


def parse_sql_aliases_from_from_join(sql: str, entity_keys: set) -> dict:
    """
    Find FROM table alias and JOIN table alias in SQL so we can map subquery aliases.
    entity_keys: set of entityStoreKey (e.g. BL1_CYCLE_CUSTOMERS).
    Returns: alias (upper) -> (schema, entity) for entities we know. We don't have schema here
    so we need to get schema from context - actually we need entity_name -> (schema, entity).
    """
    # FROM table_name alias or JOIN table_name alias (table_name can be entityStoreKey)
    pattern = re.compile(
        r"\b(?:FROM|JOIN)\s+(\w+)\s+(\w+)",
        re.IGNORECASE,
    )
    out = {}
    for m in pattern.finditer(sql):
        table_name, alias = m.group(1), m.group(2).upper()
        if table_name.upper() in entity_keys:
            out[alias] = table_name.upper()  # alias -> entity_key (schema we'll resolve later)
    return out


def columns_used_per_entity(
    sql: str,
    alias_to_schema_entity: dict,
    subquery_alias_to_entity_key: dict,
    entity_key_to_schema_entity: dict,
) -> dict:
    """
    Parse SQL for alias.column references. Return (schema, entity) -> set of column names (as in SQL).
    """
    # (schema, entity) -> set of column names
    columns_by_entity = {}
    # Merge alias maps: alias -> (schema, entity). For subquery we have alias -> entity_key (upper), resolve via entity_key_to_schema_entity
    alias_to_schema_entity_full = dict(alias_to_schema_entity)
    for alias, entity_key in subquery_alias_to_entity_key.items():
        ek = entity_key.upper() if isinstance(entity_key, str) else entity_key
        if ek in entity_key_to_schema_entity:
            alias_to_schema_entity_full[alias] = entity_key_to_schema_entity[ek]
    # Regex: word boundary, alias, dot, column (word chars). Case-insensitive for alias.
    aliases = set(alias_to_schema_entity_full.keys())
    if not aliases:
        return columns_by_entity
    # Pattern: alias.column where alias is one of ours (use alternation)
    alias_pattern = "|".join(re.escape(a) for a in aliases)
    pattern = re.compile(
        rf"\b({alias_pattern})\.([A-Za-z0-9_]+)\b",
        re.IGNORECASE,
    )
    for m in pattern.finditer(sql):
        alias_used = m.group(1).upper()
        col = m.group(2)
        if alias_used in alias_to_schema_entity_full:
            key = alias_to_schema_entity_full[alias_used]
            columns_by_entity.setdefault(key, set()).add(col)
    return columns_by_entity


def filter_attributes_to_used_columns(
    attributes: list,
    used_columns: set,
    use_name_as_column: bool,
) -> list:
    """
    Return list of attributes that are in used_columns. For ExternalEntity column is 'name';
    for CacheEntity column is 'attributeKey'. used_columns is from SQL (often same as name).
    Preserve order of attributes. Match case-insensitively.
    If used_columns is empty, returns all attributes (fallback so index is still valid).
    """
    used_upper = {c.upper() for c in used_columns} if used_columns else set()
    out = []
    for a in attributes:
        if use_name_as_column:
            col = a.get("name") or a.get("attributeKey")
        else:
            col = a.get("attributeKey") or a.get("name")
        if col and (not used_upper or col.upper() in used_upper):
            out.append(a)
    # If no columns matched (e.g. entity only in FROM), include all attributes for safety
    if not out and attributes:
        return list(attributes)
    return out


def load_external_entity(data_root: Path, schema: str, entity: str) -> dict | None:
    """Load ExternalEntity JSON. Returns None if not found."""
    name = f"INTEGRATIONLAYER_aia_ExternalEntity_{schema}_{entity}"
    path = data_root / "ExternalEntity" / name
    if not path.exists():
        return None
    with open(path) as f:
        return json.load(f)


def load_cache_entity(data_root: Path, entity: str) -> dict | None:
    """Load CacheEntity JSON. Returns None if not found."""
    name = f"INTEGRATIONLAYER_aia_CacheEntity_{entity}"
    path = data_root / "CacheEntity" / name
    if not path.exists():
        return None
    with open(path) as f:
        return json.load(f)


def attributes_to_selected_columns(attributes: list, use_name_as_column: bool = True) -> list:
    """Convert entity attributes to selectedColumns format.
    ExternalEntity: use 'name' as columnName.
    CacheEntity: use 'attributeKey' as columnName.
    """
    cols = []
    for a in attributes:
        if use_name_as_column:
            col_name = a.get("name") or a.get("attributeKey")
        else:
            col_name = a.get("attributeKey") or a.get("name")
        dt = a.get("datatype", "STRING")
        cols.append({
            "columnName": col_name,
            "expression": None,
            "dataType": normalize_datatype(dt),
        })
    return cols


def build_index_json(
    schema: str,
    entity: str,
    context_key: str,
    selected_columns: list,
) -> list:
    """Build one index table definition (array with single element)."""
    index_table_name = f"{schema}__{entity}__1__i"
    key = f"{entity}_i"
    selected_columns = selected_columns + SYSTEM_COLUMNS
    return [{
        "name": index_table_name,
        "description": f"Index table for {entity}",
        "key": key,
        "elementType": "LHCETransformIndexTable",
        "basedOn": "default-index-delta-global-key",
        "modelRefs": {
            "refType": "ENTITY",
            "layer": "INTERNAL",
            "logicalSchemaKey": schema,
            "logicalEntityKey": entity,
        },
        "writeMode": "DEFERRED_MERGE",
        "indexTableName": index_table_name,
        "selectedColumns": selected_columns,
        "contexts": [
            {"contextKey": context_key, "isUsedInTransformer": True, "hints": []},
        ],
    }]


def index_filename(schema: str, entity: str) -> str:
    """Choose index JSON filename (single variant, no nonref)."""
    return f"{entity}_index.json"


def _parse_entity_filter(entity_arg: str) -> tuple[str | None, str]:
    """Parse --entity argument: 'TABLE_CUSTOMER' or 'CRMAPP.TABLE_CUSTOMER'. Returns (schema_or_none, entity)."""
    if "." in entity_arg:
        s, e = entity_arg.split(".", 1)
        return s.strip(), e.strip()
    return None, entity_arg.strip()


def main():
    if len(sys.argv) < 3:
        print("Usage: generate_index_json.py <implementation_model_data_path> <transformation_key> [--entity ENTITY]")
        print("Example: generate_index_json.py ../../data/INTEGRATIONLAYER aLDMCustomerDataChannel-Customer-Customer")
        print("Example (one table): generate_index_json.py ../../data/INTEGRATIONLAYER aLDMCustomerDataChannel-Customer-Customer --entity TABLE_CUSTOMER")
        sys.exit(1)
    data_root = Path(sys.argv[1]).resolve()
    transformation_key = sys.argv[2]

    entity_filter = None  # (schema_or_none, entity_key)
    args = sys.argv[3:]
    if args and args[0] == "--entity" and len(args) >= 2:
        entity_filter = _parse_entity_filter(args[1])

    if not (data_root / "Transformation").exists():
        print(f"Error: {data_root} does not contain Transformation folder")
        sys.exit(1)

    transformation = load_transformation(data_root, transformation_key)
    context_key = transformation.get("contextKey")
    target_entity = transformation.get("targetEntityStoreKey") or context_key
    out_dir = (Path(__file__).parent / target_entity).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Context key: {context_key}  -> output folder: {out_dir}")
    sql = (transformation.get("customScript") or "").replace("\r\n", " ").replace("\n", " ")
    context = load_context(data_root, context_key)
    entities = get_entities_from_context(context)
    if entity_filter:
        filter_schema, filter_entity = entity_filter
        entities = [
            (s, e) for s, e in entities
            if e.upper() == filter_entity.upper() and (filter_schema is None or s.upper() == filter_schema.upper())
        ]
        if not entities:
            print(f"Error: Entity not found in context: {entity_filter}")
            sys.exit(1)
        print(f"Entity filter: {filter_schema or '*'}.{filter_entity} -> {len(entities)} matched")
    else:
        print(f"Entities: {len(entities)}")

    # Alias -> (schema, entity) from context
    alias_to_schema_entity, _ = get_alias_to_entity_and_entity_list(context)
    # entity_key (upper) -> (schema, entity) for subquery alias resolution
    entity_key_to_schema_entity = {entity.upper(): (schema, entity) for schema, entity in entities}
    entity_keys = set(entity_key_to_schema_entity.keys())
    # Subquery: FROM/JOIN table_name alias -> alias maps to entity
    subquery_alias_to_entity_key = parse_sql_aliases_from_from_join(sql, entity_keys)
    # (schema, entity) -> set of column names used in SQL
    columns_by_entity = columns_used_per_entity(
        sql, alias_to_schema_entity, subquery_alias_to_entity_key, entity_key_to_schema_entity
    )
    # (schema, entity) -> set of column names required by context relations (PK + FK)
    relation_columns_by_entity = get_relation_columns_per_entity(context, data_root)

    generated = []
    for schema, entity in entities:
        attrs = None
        use_name = True
        if schema == "CACHE":
            ent = load_cache_entity(data_root, entity)
            if ent:
                attrs = ent.get("attributes", [])
                use_name = False  # CacheEntity uses attributeKey
        else:
            ent = load_external_entity(data_root, schema, entity)
            if ent:
                attrs = ent.get("attributes", [])

        if not attrs:
            print(f"  Skip (no attributes): {schema}.{entity}")
            continue

        # Union: columns used in transformation SQL + columns required by context relations
        used_cols = columns_by_entity.get((schema, entity), set()) | relation_columns_by_entity.get(
            (schema, entity), set()
        )
        attrs_filtered = filter_attributes_to_used_columns(attrs, used_cols, use_name_as_column=use_name)
        selected = attributes_to_selected_columns(attrs_filtered, use_name_as_column=use_name)
        n_total, n_used = len(attrs), len(attrs_filtered)
        # Use target entity as contextKey in index so all index JSON in this folder share the same contextKey (e.g. Address for both Address and Eaddress transformations)
        index_arr = build_index_json(schema, entity, target_entity, selected)
        filename = index_filename(schema, entity)
        out_path = out_dir / filename
        with open(out_path, "w") as f:
            json.dump(index_arr, f, indent=2)
        print(f"  Wrote: {filename}  (columns: {n_used}/{n_total} used in SQL + relation keys)")
        generated.append(filename)

    print(
        f"\nGenerated {len(generated)} index JSON file(s) in {out_dir} "
        "(optimal: SQL-used columns + context relation PK/FK + system columns)"
    )
    return generated


if __name__ == "__main__":
    main()
