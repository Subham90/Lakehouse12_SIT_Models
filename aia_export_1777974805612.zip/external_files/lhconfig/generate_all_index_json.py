#!/usr/bin/env python3
"""
Discover all CONTEXT-based transformations in INTEGRATIONLAYER and run
generate_index_json.py for each. Index files are written to subfolders by target entity
(e.g. lhconfig/Customer/, lhconfig/ArCharge/).

Usage:
  python generate_all_index_json.py [implementation_model_data_path]

Default data path: ../../data/INTEGRATIONLAYER (relative to this script)
"""
import json
import subprocess
import sys
from pathlib import Path

def find_context_transformation_keys(data_root: Path) -> list[str]:
    """Return list of transformation keys that have sourceType CONTEXT."""
    trans_dir = data_root / "Transformation"
    if not trans_dir.exists():
        return []
    keys = []
    for f in trans_dir.iterdir():
        if not f.is_file():
            continue
        try:
            with open(f, encoding="utf-8") as fp:
                t = json.load(fp)
            if t.get("sourceType") == "CONTEXT" and t.get("contextKey"):
                key = t.get("key")
                if key:
                    keys.append(key)
        except (json.JSONDecodeError, OSError):
            continue
    return sorted(keys)


def main():
    script_dir = Path(__file__).parent.resolve()
    if len(sys.argv) >= 2:
        data_root = Path(sys.argv[1]).resolve()
    else:
        data_root = (script_dir / ".." / ".." / "data" / "INTEGRATIONLAYER").resolve()

    if not (data_root / "Transformation").exists():
        print(f"Error: {data_root} does not contain Transformation folder")
        sys.exit(1)

    keys = find_context_transformation_keys(data_root)
    print(f"Found {len(keys)} CONTEXT transformation(s)")
    if not keys:
        sys.exit(0)

    generator = script_dir / "generate_index_json.py"
    for i, key in enumerate(keys, 1):
        print(f"\n[{i}/{len(keys)}] {key}")
        try:
            subprocess.run(
                [sys.executable, str(generator), str(data_root), key],
                cwd=str(script_dir),
                check=True,
            )
        except subprocess.CalledProcessError as e:
            print(f"  Failed (exit code {e.returncode})")
        except Exception as e:
            print(f"  Error: {e}")

    print(f"\nDone. Processed {len(keys)} transformation(s).")


if __name__ == "__main__":
    main()
